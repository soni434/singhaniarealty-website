# singhaniarealty-website
This is Singhania Dreamscapes Realty Limited Website
<br>
I have used HTML & CSS to develop this website 
<br>
Developer: Prashant Soni 
<br>
Company: Singhania Internatinal Limited